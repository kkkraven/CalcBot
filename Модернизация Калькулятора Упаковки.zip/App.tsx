import { PackagingCalculator } from "./components/PackagingCalculator";

export default function App() {
  return <PackagingCalculator />;
}